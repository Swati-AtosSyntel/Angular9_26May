import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic',
  templateUrl: './basic.component.html',
  //template:'<h1>{{message}}</h1>',
  //template:`<h1>

  //{{message}}
  //<h1>`,
  styleUrls: ['./basic.component.css']
})
export class BasicComponent implements OnInit {

  message="This is basic compoenent";
isSelected=true;
  constructor() { }

  ngOnInit(): void {
  }

}
