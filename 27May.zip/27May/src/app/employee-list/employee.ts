export interface IEmployee{
    id:number;
    name:string;
    city:string;
    salary:number;
    gender:string;
    age:number;
    dob:Date;
    pan:string;
    mobile:string;
}