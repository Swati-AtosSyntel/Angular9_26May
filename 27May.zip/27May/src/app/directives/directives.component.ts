import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css','../basic/basic.component.css']
})
export class DirectivesComponent implements OnInit {

  colors=['Red','Green','Blue','Orange'];
  show=true;
  day=1;
  constructor() { }

  ngOnInit(): void {
  }

}
