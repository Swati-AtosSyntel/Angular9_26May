import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppComponent } from '../app.component';
import { EmployeeListComponent } from '../employee-list/employee-list.component';
import { HttpclientexampleComponent } from '../httpclientexample/httpclientexample.component';
import { PagenotfoundComponent } from '../pagenotfound/pagenotfound.component';
import {Routes,RouterModule} from '@angular/router';
const routes:Routes=[
  {path:'home',component:AppComponent},
  {path:'employee',component:EmployeeListComponent},
  {path:'user',component:HttpclientexampleComponent},
  {path:'',redirectTo:'home',pathMatch:'full'},
  {path:'**',component:PagenotfoundComponent}
];
@NgModule({
  declarations: [
   
  ],
  imports: [
    CommonModule,RouterModule.forRoot(routes)
  ],
  exports:[RouterModule]
})

export class AppRoutingModule { }
