import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'This is FirstAngularApp';
  fname:string="Aakash";
  lname="Patil";
  fullName;
  
  getFullName(){
    this.fullName=this.fname+" "+this.lname;

  }
}
