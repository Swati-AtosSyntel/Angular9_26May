import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { BasicComponent } from './basic/basic.component';
import { DirectivesComponent } from './directives/directives.component';
import { EmployeeComponent } from './employee/employee.component';
import { GenderPipe } from './gender.pipe';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeecountComponent } from './employeecount/employeecount.component';

@NgModule({
  declarations: [
    AppComponent,
    BasicComponent,
    DirectivesComponent,
    EmployeeComponent,
    GenderPipe,
    EmployeeListComponent,
    EmployeecountComponent
  ],
  imports: [
    BrowserModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
