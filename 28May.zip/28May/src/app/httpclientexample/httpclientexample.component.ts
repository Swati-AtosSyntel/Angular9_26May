import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-httpclientexample',
  templateUrl: './httpclientexample.component.html',
  styleUrls: ['./httpclientexample.component.css']
})
export class HttpclientexampleComponent implements OnInit {

  constructor(private http:HttpClient) { }
  httpdata;
  searchId=2;
  ngOnInit(): void {
    this.http.get("http://jsonplaceholder.typicode.com/users")
        .subscribe((data)=>{this.displayData(data);console.log(data)},
        (error)=>{
          console.log('Request failed');
          console.log(error);
        },
        ()=>{ 
          console.log("Request completed");
        })

  }
  serachUser(){
    this.http.get("http://jsonplaceholder.typicode.com/users?id="+this.searchId)
    .subscribe((data)=>{this.displayData(data);console.log(data)},
    (error)=>{
      console.log('Request failed');
      console.log(error);
    },
    ()=>{ 
      console.log("Request completed");
    })

    
  }


displayData(data){
  this.httpdata=data;

}

}
