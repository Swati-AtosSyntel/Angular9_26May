import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-employeecount',
  templateUrl: './employeecount.component.html',
  styleUrls: ['./employeecount.component.css']
})
export class EmployeecountComponent implements OnInit {

  @Input()
  All:string;
  @Input()
  Male:string;
  @Input()
  Female:string;

  selectedRadioButtonValue:string='All';//this will keeps track of value of selected radio button
  @Output()
  countRadioButtonSelectionchanged:EventEmitter<string>=new EventEmitter<string>();
  constructor() { }
  onRadioButtonSelectionchange(){
    this.countRadioButtonSelectionchanged.emit(this.selectedRadioButtonValue);
    console.log(this.selectedRadioButtonValue);
  }
  ngOnInit(): void {
  }

}
