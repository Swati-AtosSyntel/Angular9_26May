import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { BasicComponent } from './basic/basic.component';
import { DirectivesComponent } from './directives/directives.component';
import { EmployeeComponent } from './employee/employee.component';
import { GenderPipe } from './gender.pipe';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeecountComponent } from './employeecount/employeecount.component';
import { HttpclientexampleComponent } from './httpclientexample/httpclientexample.component';
import {HttpClientModule} from '@angular/common/http';
import {AppRoutingModule} from './app-routing/app-routing.module';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
@NgModule({
  declarations: [
    AppComponent,
    BasicComponent,
    DirectivesComponent,
    EmployeeComponent,
    GenderPipe,
    EmployeeListComponent,
    EmployeecountComponent,
    HttpclientexampleComponent,
    PagenotfoundComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
